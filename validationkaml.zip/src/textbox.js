export const Textbox = () => {
    return (
        <>
            <label for="fname">First name:</label>
            <input type="text" id="fname" name="fname" />

            <br /><br /><br />
        </>
    )

}     
export const Textbox1 = () => {
    return (
        <>
            <label for="fname">last name:</label>
            <input type="text" id="fname" name="fname" />

            <br /><br /><br />
        </>
    )

}      