import { useState,useEffect } from "react";
import { Form, Button, Input } from 'antd';
import { useNavigate } from 'react-router-dom';
import axios from "axios";

const Livevalidation = () => {
    
    const [name, setName] = useState("");
    const [id, setId] = useState("");
    const [message, setMessage] = useState("");
    const [posts, setPosts] = useState([]);
  


  const dataArr=["jeff" , "sarath" ]


  const triggerChange = (e) => {
    setId(e.target.value);


    // if (posts.id.includes(name)) {
    //  console.log("success")
    // }
    // else{
    //  console.log("not")
    // }
   };
    
  useEffect(() => {
    // const loadPost = async () => {

    //     // Till the data is fetch using API 
    //     // the Loading page will show.
    //     // setLoading(true);

    //     // Await make wait until that 
    //     // promise settles and return its result
    //     const response = await axios.get(
    //     "https://jsonplaceholder.typicode.com/posts/");

    //     // After fetching data stored it in posts state.
    //     setPosts(response.data);

    //     console.log(posts)

    //     // Closed the loading page
    //     // setLoading(false);
    // }

    // // Call the function
    // loadPost();




    
  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch("Enter The Api here", {
        
        method: "POST",
        body: JSON.stringify({
         user_id:id,

          
        }),
      });
      let resJson = await res.json();
      if (resJson=="True") {
        
       
        alert("user already exists")
      } else {
        setMessage("Some error occured");
      }
    } catch (err) {
      console.log(err);
    }
  };

  handleSubmit();
}, []);

  
//  quia et suscipit\nsuscipit recusandae consequuntur



 
    
  return (
    <div>
    <div className='form'>

      <Form 
      labelCol={{ span : 8}}
      wrapperCol={{ span : 24}}
      autoComplete='off'
      >
       <h1>Login</h1> 
       <Form.Item 
        name="user_id" 
        value={id}

        rules={[
          {
            required: true,
            message: "Please enter your ID",
          },
          {
            whitespace:true,
            message : false
          },
          {
            min:4,
            message:'ID Must be atleast 4 characters'
          },
          {
            max:6,
            message:"ID must not exceed more than 6 characters"
          },
          {
            message:{message}
          }
          
        ]}
        hasFeedback
        >
            
          <Input 
            placeholder="ID " required/>
        </Form.Item>
        <Form.Item 
        name="username" 
        value={name}
        validateStatus="validating"
        onChange={triggerChange}
      

        rules={[
          {
            required: true,
            message: "Please enter your name",
          },
          {
            whitespace:true,
            message : false
          },
          {
            min:2,
            message:'User Name Must be atleast 2 characters'
          },
          {
            message:{message}
          }
          
        ]}
        hasFeedback
       
        >
            
          <Input 
            placeholder="Username" required/>
        </Form.Item>
        <Form.Item
        name= 'password'
        rules={[
          {
            required: true,
            message: 'Password cannot be empty'
          }, 
          {
            min : 4,
            message : 'Password must be atleast having 4 Characters'
          },
          {
            
          }
      ]}   
        >
          <Input.Password 
           
            placeholder="Password" required/>
        </Form.Item>
        <Button
        onClick={() => {
            triggerChange()
      }} 
        type="primary" block htmlType='submit' className="login-form-button">
            Log in
        </Button>
        <div className='signUp'>
        
         
          </div>
          
      </Form>
      </div>
      </div>
  )
}

export default Livevalidation