import { useState } from "react";
import { Form, Button, Input } from 'antd';
import { useNavigate } from 'react-router-dom';
import axios from "axios";


const Validateres = () => {


    
} 

export default Validateres