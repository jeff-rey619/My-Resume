import './App.css';
import 'antd/dist/antd.css';
import Antd from './components/antd';
import Livevalidation from './components/LiveValidation';


//import { Signup } from './components/SignUp';

function App() {
  return (
    <div className="container mt-3">
      <div className="row">
        <div className="col-md-5">
          {/*<Signup />*/}
          {/* <Antd/> */}
          <Livevalidation/>
        </div>
       
      </div>
    </div>
  );
}

export default App;